#pragma once

const double EPS = 1e-9;
const int SINGLE = 1;
const int MIN_POINT_AMOUNT = 3;